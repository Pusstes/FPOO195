from tkinter import *
from tkinter import ttk
import tkinter as tk
import sqlite3
from Controlador import *

objControlador = Controlador() #crear un objeto de la clase Controlador

def ejecutarInsert():
    objControlador.insertUsuario(var1.get(), var2.get(), var3.get()) #llamar al método insertUsuario de la clase Controlador

def buscar():
    usuario = objControlador.buscarUsuario(varBus.get()) #llamar al método buscarUsuario de la clase Controlador
    print(usuario)
    
#creacion de la ventana
ventana = Tk()
ventana.title("CRUD de Usuarios")
ventana.geometry("500x500")

# Crear el panel de pestañas
panel = ttk.Notebook(ventana)
panel.pack(fill='both', expand='yes')

# Crear las pestañas con el metodo frame
pestana1 = ttk.Frame(ventana)
pestana2 = ttk.Frame(ventana)
pestana3 = ttk.Frame(ventana)
pestana4 = ttk.Frame(ventana)
pestana5 = ttk.Frame(ventana)

# Añadir las pestañas al panel con la propiedad add
panel.add(pestana1, text='Crear Usuario')
panel.add(pestana2, text='Buscar Usuario')
panel.add(pestana3, text='ConsultarUsuarios')
panel.add(pestana4, text='Actualizar Usuario')
panel.add(pestana5, text='Eliminar Usuario')


#pestaña 1: Formulario para crear un usuario
Label(pestana1, text="Registro de usuarios",fg="blue", font=("modern",18)).pack()

var1 = tk.StringVar()
Label(pestana1, text="Nombre:").pack()
Entry(pestana1, textvariable=var1).pack()

var2 = tk.StringVar()
Label(pestana1, text="Email:").pack()   
Entry(pestana1, textvariable=var2).pack()  

var3 = tk.StringVar()
Label(pestana1, text="Contraseña:").pack()  
Entry(pestana1, textvariable=var3).pack()

boton = Button(pestana1, text="Guardar", bg="green", fg="white", command=ejecutarInsert)
boton.pack()

#pestaña2: Buscar usuario
Label(pestana2, text="Buscar usuario por ID",fg="blue", font=("modern",18)).pack() #etiqueta de título
varBus = tk.StringVar() #variable para almacenar el ID
Label(pestana2, text="Ingrese el ID").pack() #etiqueta para el campo de texto
Entry(pestana2, textvariable=varBus).pack() #campo de texto
Button(pestana2, text="Buscar", bg="green", fg="white",command=buscar).pack() #botón de búsqueda
Label(pestana2, text="Resultado de la búsqueda",fg="blue", font=("modern",18)).pack() #etiqueta de título
tk.Text(pestana2, height=5, width=52).pack() #área de texto para mostrar el resultado

#pestaña 3: Consultar usuarios
Label(pestana3, text="Usuarios registrados",fg="blue", font=("modern",18)).pack()


ventana.mainloop()




